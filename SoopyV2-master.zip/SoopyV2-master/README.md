### NOTE This is no-longer maintained as I have moved to working for badlion:
[https://badlion.net](https://www.badlion.net/?utm_source=SoopyMods&utm_medium=web&utm_campaign=brand_awareness)

# SoopyV2

DOWNLOAD AT https://github.com/Soopyboo32/SoopyV2Forge/releases

More info at https://soopy.dev/soopyv2

A complete recode of the original soopyaddons chattriggers module (https://github.com/Soopyboo32/soopyaddons) with a lot of improvements

https://www.chattriggers.com/modules/v/SoopyV2
