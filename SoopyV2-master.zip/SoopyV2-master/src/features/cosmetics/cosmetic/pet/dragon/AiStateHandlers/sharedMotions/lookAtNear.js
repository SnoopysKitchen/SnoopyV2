/**
 * Pet is not moving, should look at nearbye players! 
 * @param {import("../../dragon.js").default} pet 
 */
export default function (pet) {

}